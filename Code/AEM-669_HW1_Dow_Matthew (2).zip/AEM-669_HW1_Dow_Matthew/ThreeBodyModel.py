import numpy as np
from scipy.optimize import newton

def CR3BP_nondim(t, X, mu):
    x, y, z, vx, vy, vz = X

    d = np.sqrt(np.sum(np.square([x+mu,y,z])))
    r = np.sqrt(np.sum(np.square([x-1+mu,y,z])))

    ax = 2*vy + x - ((1-mu)*(x+mu))/(d**3) - (mu*(x-1+mu))/(r**3)
    ay = -2*vx + y - ((1-mu)*y)/(d**3) - (mu*y)/(r**3)
    az = - ((1-mu)*z)/(d**3) - (mu*z)/(r**3)

    return [vx,vy,vz,ax,ay,az]

def ColinearLagrangePointFunction(x, mu):
    return x - (((1-mu)*(x+mu))/np.abs(x+mu)**3) - ((mu*(x-1+mu))/np.abs(x-1+mu)**3)

def Get3BodyColinearLibrationPoints(mu, Lstar):
    x1 = newton(func=ColinearLagrangePointFunction, x0 = 0, args=(mu,))
    g1 = 1 - mu - x1
    g1_dim = g1 * Lstar

    x2 = newton(func=ColinearLagrangePointFunction, x0 = 1, args=(mu,))
    g2 = x2 - 1 + mu
    g2_dim = g2 * Lstar

    x3 = newton(func=ColinearLagrangePointFunction, x0 = -1, args=(mu,))
    g3 = -mu - x3
    g3_dim = g3*Lstar

    return [x1,x2,x3],[g1,g2,g3],[g1_dim,g2_dim,g3_dim]

def Get3BodyEquilateralLagrangePoints(mu):
    x = 0.5 - mu
    y4 = np.sqrt(3)/2
    y5 = -np.sqrt(3)/2 
    return (x,y4),(x,y5)

def GetJacobiConstant(pos,vel,mu):
    d = np.sqrt((pos[0]+mu)**2 + pos[1]**2 + pos[2]**2)
    r = np.sqrt((pos[0]-1+mu)**2 + pos[1]**2 + pos[2]**2)
    v_mag_sqr = vel[0]**2 + vel[1]**2 + vel[2]**2
    return pos[0]**2 + pos[1]**2 + (2*(1-mu)/d) + (2*mu/r) - v_mag_sqr