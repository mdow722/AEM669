from scipy.integrate import solve_ivp
import numpy as np
import matplotlib.pyplot as plt
from ThreeBodyModel import *
from PlanetaryDataFuncs import *

# These masses represent the Earth-Moon system
m_1 = 5.974E24  # kg
m_2 = 7.348E22 # kg
mu = m_2/(m_1 + m_2)
print(mu)
Lstar,Mstar,Tstar,mu = Get3BodyCharacteristics("Earth","Moon")
Vstar = Lstar/Tstar
print(mu)

x_0 = -0.270
y_0 = -0.420
z_0 = 0
r_dim = [x_0*Lstar,y_0*Lstar,z_0*Lstar]
print("r_dim",r_dim)

vx_0 = 0.300
vy_0 = -1.00
vz_0 = 0
v_dim = [vx_0*Vstar,vy_0*Vstar,vz_0*Vstar]
print("v_dim",v_dim)

# Then stack everything together into the state vector
# r_0 = np.array((x_0, y_0, z_0))
# v_0 = np.array((vx_0, vy_0, vz_0))
# Y_0 = np.hstack((r_0, v_0))
Y_0 = np.array((x_0,y_0,z_0,vx_0,vy_0,vz_0))

t_0 = 0  # nondimensional time
t_f = 100000  # nondimensional time
t_points = np.linspace(t_0, t_f, t_f*100)
sol = solve_ivp(CR3BP_nondim, [t_0,t_f], Y_0, t_eval=t_points, args=(mu,))

Y = sol.y.T
r = Y[:, :3]  # nondimensional distance
v = Y[:, 3:]  # nondimensional velocity

x_2 = (1 - mu) * np.cos(np.linspace(0, np.pi, 100))
y_2 = (1 - mu) * np.sin(np.linspace(0, np.pi, 100))
fig, ax = plt.subplots(figsize=(5,5), dpi=96)

# Plot the orbits
ax.plot(r[:, 0], r[:, 1], 'r', label="Trajectory")
ax.axhline(0, color='k')
ax.plot(np.hstack((x_2, x_2[::-1])), np.hstack((y_2, -y_2[::-1])))
ax.plot(-mu, 0, 'bo', label="$m_1$")
ax.plot(1 - mu, 0, 'go', label="$m_2$")
ax.plot(x_0, y_0, 'ro')
ax.set_aspect("equal")
plt.show()